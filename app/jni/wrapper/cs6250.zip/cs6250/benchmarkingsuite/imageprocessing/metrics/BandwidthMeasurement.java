package cs6250.benchmarkingsuite.imageprocessing.metrics;

public class BandwidthMeasurement {
    public native boolean launchBandwidthTest(String serverIp);
    public native long getUploadedBytes();
    public native long getDownloadedBytes();
    public native double getTimeTaken();
    public native long getHostCpuUtilization();
    public native long getServerCpuUtilization();
    public native boolean cleanup();
}
