package cs6250.benchmarkingsuite.imageprocessing.metrics;

/**
 * Created by farzon on 11/22/17.
 */

public class IperfWrapper {

    private native long newTestImpl();
    private native void freeTestImpl(long ref);
    private native void testRoleImpl(long ref, char role);
    private native void defaultsImpl(long ref);
    private native void hostnameImpl(long ref, String host);
    private native void tempFileTemplateImpl(long ref, String template);
    private native void durationImpl(long ref, int duration);
    private native void logFileImpl(long ref, String logfile);
    private native void runClientImpl(long ref);
    private native void outputJsonImpl(long ref, boolean useJson);
    
    public native long getUploadedBytes();
    public native long getDownloadedBytes();
    public native double getTimeTaken();
    public native double[] getHostCpuUtilization(long ref);
    public native double[] getServerCpuUtilization(long ref);
}