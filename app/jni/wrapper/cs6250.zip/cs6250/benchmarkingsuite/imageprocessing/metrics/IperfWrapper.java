package cs6250.benchmarkingsuite.imageprocessing.metrics;

/**
 * Created by farzon on 11/22/17.
 */

public class IperfWrapper {

    private native boolean initNativeIperfImpl();
    private native void cleanUp();
    private native void testRoleImpl(char role);
    private native void defaultsImpl();
    private native void hostnameImpl(String host);
    private native void tempFileTemplateImpl(String template);
    private native void durationImpl(int duration);
    private native void logFileImpl(String logfile);
    private native void runClientImpl();
    private native void outputJsonImpl(boolean useJson);

    public native long getUploadedBytes();
    public native long getDownloadedBytes();
    public native double getTimeTaken();
    public native double[] getHostCpuUtilization();
    public native double[] getServerCpuUtilization();
}