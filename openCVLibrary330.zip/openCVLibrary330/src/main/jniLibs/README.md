You need to copy the contents of OpenCV-android-sdk/sdk/native/libs into this directory
